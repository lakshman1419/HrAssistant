# Agent Workflow Dashboard

## 1. Overview

Build a real-time **Agent Workflow Dashboard** for the HR Assistant application.

The dashboard should provide visibility into the background work performed by the multi-agent workflow.

The user should be able to see:

* Which agent is currently working
* Which agents have completed
* Which agents are waiting
* Which agents failed
* Current task being executed
* Agent execution timeline
* Real-time activity logs
* Files created or modified
* Tool calls performed
* Workflow progress
* Agent execution duration
* Overall workflow status

The dashboard is intended for **development-time monitoring and debugging** of the HR Assistant agent workflow.

---

# 2. Technology

Use the existing project technology stack.

## Frontend

* Angular
* TypeScript
* HTML
* SCSS/CSS
* Angular standalone components where applicable
* RxJS for real-time event handling

## Backend

* ASP.NET Core
* C#
* SignalR for real-time agent events

## Communication

The architecture should support:

```text
Agent Workflow
      |
      v
.NET Agent Event Service
      |
      v
SignalR Hub
      |
      v
Angular Dashboard
```

Do not hard-code agent status in the Angular application.

The dashboard must consume agent events from the backend.

---

# 3. Dashboard Layout

Create a modern developer/AI-agent monitoring dashboard.

Use a clean layout similar to an observability dashboard.

## Header

Display:

```text
HR Assistant
Agent Workflow Monitor
```

Header information:

```text
Workflow ID: HR-2026-001
Status: Running
Started: 14:32:10
Duration: 02:35
```

Include:

* Connection status
* Refresh/reconnect indicator
* Current workflow status

Example:

```text
┌─────────────────────────────────────────────────────────────┐
│ 🤖 HR Assistant - Agent Workflow Monitor       🟢 Connected │
│ Workflow: HR-2026-001                         Status: RUNNING│
└─────────────────────────────────────────────────────────────┘
```

---

# 4. Summary Cards

Display summary cards below the header.

Cards:

```text
Total Agents
Completed
Working
Waiting
Failed
```

Example:

```text
┌──────────────┐
│ Total Agents │
│      6       │
└──────────────┘

┌──────────────┐
│ Completed    │
│      2       │
└──────────────┘

┌──────────────┐
│ Working      │
│      1       │
└──────────────┘

┌──────────────┐
│ Waiting      │
│      2       │
└──────────────┘

┌──────────────┐
│ Failed       │
│      1       │
└──────────────┘
```

Values must be calculated dynamically from the agent state.

---

# 5. Agent Status Section

Display every agent involved in the workflow.

Example agents:

```text
Orchestrator
Planner
Angular UI Agent
Backend Agent
RAG Agent
Test Agent
Security Agent
Documentation Agent
```

Each agent should have:

* Agent name
* Status
* Current task
* Start time
* Completion time
* Duration
* Last activity
* Number of tool calls
* Number of files changed

Example:

```text
┌─────────────────────────────────────────────┐
│ 🎨 Angular UI Agent                         │
│                                             │
│ 🔵 WORKING                                  │
│                                             │
│ Current Task:                               │
│ Building HR Assistant chat interface        │
│                                             │
│ Started: 14:35:21                            │
│ Duration: 24 seconds                         │
│                                             │
│ Files Changed: 3                             │
│ Tool Calls: 7                                │
└─────────────────────────────────────────────┘
```

---

# 6. Agent Statuses

Support these states:

```text
WAITING
WORKING
COMPLETED
FAILED
CANCELLED
```

Use clear visual indicators.

```text
WAITING     → ⏳
WORKING     → 🔵
COMPLETED   → ✅
FAILED      → ❌
CANCELLED   → ⚪
```

The UI should visually distinguish the states.

Do not rely only on color.

Display the status text as well.

---

# 7. Agent Workflow Timeline

Create a visual workflow pipeline.

Example:

```text
Orchestrator
     |
     v
Planner
     |
     v
Angular UI Agent
     |
     v
Backend Agent
     |
     v
RAG Agent
     |
     v
Test Agent
     |
     v
Security Agent
     |
     v
Documentation Agent
```

Display the current agent prominently.

Example:

```text
✅ Planner
      |
      v
🔵 Angular UI Agent
   WORKING
      |
      v
⏳ Backend Agent
   WAITING
```

The workflow should update automatically when an agent starts or completes.

---

# 8. Current Activity Panel

Display the activity currently being performed.

Example:

```text
CURRENT ACTIVITY

🔵 Angular UI Agent

Building HR Assistant chat interface

Current operation:
Creating chat.component.html

Progress:
██████████████░░░░░░ 70%
```

If progress percentage is not available from the agent runtime, do not invent a percentage.

Instead display:

```text
Status: Working...
```

---

# 9. Real-Time Activity Log

Create a real-time activity log.

Example:

```text
ACTIVITY LOG

14:32:10  🟢 Orchestrator started workflow
14:32:12  🟢 Planner started
14:32:25  ✅ Planner completed
14:32:27  🟢 Angular UI Agent started
14:32:31  🔧 Reading project structure
14:32:38  🔧 Creating chat.component.ts
14:32:42  🔧 Creating chat.component.html
14:32:45  🔧 Creating chat.component.scss
14:33:01  ✅ Angular UI Agent completed
14:33:03  🟢 Backend Agent started
```

New events should appear without refreshing the browser.

Provide:

* Auto-scroll
* Timestamp
* Agent name
* Event type
* Message

Allow the user to pause auto-scroll if needed.

---

# 10. Agent Details

When the user clicks an agent, display detailed information.

Example:

```text
Angular UI Agent

Status
WORKING

Task
Build HR Assistant chat interface

Started
14:35:21

Duration
00:24

Files Changed

✓ chat.component.ts
✓ chat.component.html
✓ chat.component.scss

Tool Calls

✓ Read project structure
✓ Read requirements
✓ Created component
✓ Updated styles
```

Use a side panel or modal.

---

# 11. Files Changed

Display files created or modified by agents.

Example:

```text
FILES CHANGED

Angular UI Agent

✓ src/app/chat/chat.component.ts
✓ src/app/chat/chat.component.html
✓ src/app/chat/chat.component.scss
✓ src/app/services/hr-assistant.service.ts
```

Show:

* Created
* Modified
* Deleted

Example:

```text
🆕 Created
✏️ Modified
🗑️ Deleted
```

---

# 12. Tool Calls

Display tools invoked by agents when that information is available.

Example:

```text
TOOL ACTIVITY

Angular UI Agent

✓ Read file
✓ Search code
✓ Create file
✓ Modify file
✓ Run npm test
```

Each tool call should include:

```text
Timestamp
Tool name
Agent
Status
Duration
```

---

# 13. Error Panel

If an agent fails, show a clear error.

Example:

```text
┌─────────────────────────────────────────────┐
│ ❌ Backend Agent                            │
│                                             │
│ Status: FAILED                              │
│                                             │
│ Error:                                      │
│ API connection failed                      │
│                                             │
│ Time: 14:41:22                              │
│                                             │
│ [Retry Agent]                               │
└─────────────────────────────────────────────┘
```

The Retry button should invoke the backend workflow only when retry functionality is actually implemented.

Do not create fake retry behavior.

---

# 14. Workflow Controls

Provide controls where supported:

```text
[ Start Workflow ]
[ Pause ]
[ Resume ]
[ Cancel ]
```

Only display controls that are actually supported by the backend.

Do not implement UI buttons that perform no action.

---

# 15. Real-Time Communication

Use SignalR for real-time updates.

Recommended architecture:

```text
Agent
  |
  | Agent Event
  v
Agent Event Service
  |
  v
SignalR Hub
  |
  v
Angular SignalR Service
  |
  v
RxJS Observable
  |
  v
Dashboard Components
```

Create an Angular service similar to:

```text
agent-monitor.service.ts
```

Responsibilities:

* Connect to SignalR
* Disconnect from SignalR
* Reconnect automatically
* Receive agent events
* Expose events using RxJS
* Handle connection errors

---

# 16. Agent Event Model

Create a common event model.

Example:

```typescript
export interface AgentEvent {
  workflowId: string;
  agentId: string;
  agentName: string;

  status:
    | 'WAITING'
    | 'WORKING'
    | 'COMPLETED'
    | 'FAILED'
    | 'CANCELLED';

  eventType: string;

  message: string;

  timestamp: string;

  startedAt?: string;
  completedAt?: string;

  durationMs?: number;

  currentTask?: string;

  filesChanged?: string[];

  toolName?: string;

  error?: string;
}
```

---

# 17. Backend Event Contract

The backend should publish events whenever an important agent lifecycle event occurs.

Examples:

```text
AgentStarted
AgentWorking
AgentToolCalled
AgentFileChanged
AgentCompleted
AgentFailed
AgentCancelled
WorkflowStarted
WorkflowCompleted
WorkflowFailed
```

Example event:

```json
{
  "workflowId": "HR-2026-001",
  "agentId": "angular-ui",
  "agentName": "Angular UI Agent",
  "status": "WORKING",
  "eventType": "AgentStarted",
  "message": "Building HR Assistant chat interface",
  "timestamp": "2026-09-11T14:35:21"
}
```

---

# 18. Workflow State

Maintain the current workflow state on the frontend.

Example:

```typescript
export interface WorkflowState {
  workflowId: string;
  status: string;
  agents: AgentState[];
  activityLog: AgentEvent[];
}
```

Do not reload the entire dashboard for every event.

Update only the affected agent and activity log.

---

# 19. Connection Handling

Display SignalR connection status.

States:

```text
🟢 Connected
🟡 Reconnecting
🔴 Disconnected
```

Example:

```text
SignalR: 🟢 Connected
```

When disconnected:

```text
SignalR: 🔴 Disconnected

Attempting to reconnect...
```

Automatically reconnect when possible.

---

# 20. Responsive Design

The dashboard must work on:

* Desktop
* Laptop
* Tablet

Desktop layout:

```text
┌─────────────────────────────────────────────┐
│ Header                                      │
├─────────────────────────────────────────────┤
│ Summary Cards                               │
├───────────────────────┬─────────────────────┤
│ Agent Workflow        │ Current Activity   │
│                       │                     │
├───────────────────────┴─────────────────────┤
│ Activity Log                                │
└─────────────────────────────────────────────┘
```

On smaller screens, stack sections vertically.

---

# 21. Angular Component Structure

Use a maintainable component structure.

Suggested:

```text
src/app/
│
├── agent-dashboard/
│   │
│   ├── agent-dashboard.component.ts
│   ├── agent-dashboard.component.html
│   ├── agent-dashboard.component.scss
│   │
│   ├── components/
│   │   ├── workflow-header/
│   │   ├── summary-cards/
│   │   ├── agent-list/
│   │   ├── agent-card/
│   │   ├── workflow-timeline/
│   │   ├── current-activity/
│   │   ├── activity-log/
│   │   ├── agent-details/
│   │   └── connection-status/
│   │
│   ├── models/
│   │   ├── agent-event.model.ts
│   │   ├── agent-state.model.ts
│   │   └── workflow-state.model.ts
│   │
│   └── services/
│       └── agent-monitor.service.ts
```

Follow the existing Angular project conventions if they differ.

---

# 22. State Management

For the POC, RxJS is sufficient.

Use:

```text
BehaviorSubject
Observable
Subject
```

for workflow state and real-time events.

Avoid introducing NgRx or another state-management library unless the existing project already uses it or the application complexity requires it.

---

# 23. Loading State

When the dashboard initially loads:

```text
Connecting to Agent Workflow...

🔄 Connecting...
```

After connection:

```text
🟢 Connected
Waiting for workflow events...
```

---

# 24. Empty State

If no workflow is running:

```text
No active workflow

Start an HR Assistant workflow to monitor
agent activity in real time.

[Start Workflow]
```

Only show the button if the backend supports starting workflows.

---

# 25. Error Handling

Handle:

* SignalR connection failure
* Invalid events
* Missing agent information
* Backend unavailable
* Workflow failure
* Agent failure

Do not allow one malformed event to break the entire dashboard.

---

# 26. Performance

The dashboard should support a large number of events.

Implement:

* Efficient RxJS subscriptions
* Proper unsubscribe/destroy handling
* Limited activity-log retention in the browser
* Avoid unnecessary Angular change detection
* Avoid recreating the entire agent list for every event

For the POC, retain a reasonable number of recent events, such as the latest 500 events.

Make the retention value configurable.

---

# 27. UX Requirements

The dashboard should feel like a professional AI-agent monitoring tool.

Use:

* Clean cards
* Clear typography
* Status badges
* Timeline visualization
* Expandable agent details
* Smooth state transitions
* Fixed activity-log area
* Responsive layout

Avoid excessive animations.

Animations should communicate state changes rather than distract the user.

---

# 28. Important Implementation Rule

The dashboard must represent **actual runtime events**.

Do not simulate agent execution.

Do not hard-code:

```text
Planner = Completed
Angular = Working
Backend = Waiting
```

Instead:

```text
Agent Runtime
      ↓
Real Event
      ↓
SignalR
      ↓
Angular
      ↓
Dashboard
```

If the backend does not yet expose an event, show the agent as:

```text
UNKNOWN
```

or use the last known state.

Do not fabricate activity.

---

# 29. Development Phases

Implement in the following order.

## Phase 1 — UI

Build:

* Header
* Summary cards
* Agent cards
* Timeline
* Current activity
* Activity log
* Agent details

Use mock data temporarily only for UI development.

Clearly isolate mock data so it can be removed easily.

## Phase 2 — Event Model

Create:

```text
AgentEvent
AgentState
WorkflowState
```

## Phase 3 — SignalR

Implement:

```text
.NET SignalR Hub
Angular SignalR Service
```

## Phase 4 — Agent Integration

Connect actual workflow agent events.

## Phase 5 — Validation

Verify:

```text
Workflow starts
      ↓
Orchestrator event appears
      ↓
Planner event appears
      ↓
Planner completes
      ↓
Angular Agent starts
      ↓
Angular Agent completes
      ↓
Backend Agent starts
      ↓
...
```

## Phase 6 — Error Scenarios

Test:

* Agent failure
* Backend failure
* SignalR disconnect
* Reconnect
* Workflow cancellation

---

# 30. Acceptance Criteria

The implementation is complete when:

* [ ] Dashboard loads successfully
* [ ] All configured agents are displayed
* [ ] Agent status is displayed
* [ ] Workflow timeline is displayed
* [ ] Current activity is displayed
* [ ] Real-time activity log works
* [ ] Agent details can be viewed
* [ ] SignalR connection status is visible
* [ ] Agent started event updates the UI
* [ ] Agent completed event updates the UI
* [ ] Agent failed event updates the UI
* [ ] Workflow completed event updates the UI
* [ ] Workflow failed event updates the UI
* [ ] Agent duration is displayed when available
* [ ] Tool activity is displayed when available
* [ ] File changes are displayed when available
* [ ] Reconnection is handled
* [ ] Dashboard is responsive
* [ ] No agent activity is fabricated
* [ ] Existing Angular project conventions are preserved
* [ ] Existing backend functionality is not broken

---

# 31. Final Expected Result

The final application should provide a live view similar to:

```text
HR ASSISTANT
Agent Workflow Monitor

🟢 Connected

Workflow: HR-2026-001
Status: RUNNING

────────────────────────────────────────────

6 AGENTS

✅ Planner
✅ Requirements Agent
🔵 Angular UI Agent
⏳ Backend Agent
⏳ RAG Agent
⏳ Test Agent

────────────────────────────────────────────

CURRENT ACTIVITY

🔵 Angular UI Agent

Creating:
chat.component.html

────────────────────────────────────────────

WORKFLOW

Orchestrator
     ↓
✅ Planner
     ↓
🔵 Angular UI Agent
     ↓
⏳ Backend Agent
     ↓
⏳ RAG Agent
     ↓
⏳ Test Agent

────────────────────────────────────────────

ACTIVITY LOG

14:32:10  Orchestrator started
14:32:12  Planner started
14:32:25  Planner completed
14:32:27  Angular UI Agent started
14:32:31  Reading project structure
14:32:38  Creating chat component
```

The primary goal is to make the **multi-agent development workflow observable in real time** while keeping the dashboard independent from the internal implementation of individual agents.
